// Rewritten by ChatGPT

#pragma once
enum class GeometryType
{
	CUBE,
	CYLINDER,
	CONE,
	QUAD
};